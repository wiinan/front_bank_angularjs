const gulp = require("gulp");
const babel = require("gulp-babel");
const uglify = require("gulp-uglify");
const uglifycss = require("gulp-uglifycss");
const concat = require("gulp-concat");
const htmlmin = require("gulp-htmlmin");

gulp.task("app", ["app.html", "app.css", "app.js", "app.assets"]);


