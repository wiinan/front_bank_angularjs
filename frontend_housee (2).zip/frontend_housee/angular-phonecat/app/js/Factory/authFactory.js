angular
  .module("BankApp")
  .factory("auth", [
    "$http",
    "$window",
    "consts",
    "msgs",
    "$http",
    AuthFactory,
  ]);

function AuthFactory($http, $window, consts, msgs) {
  let user = null;

  function getUser() {
    if (!user) {
      user = JSON.parse(localStorage.getItem(consts.userKey));
    }
    return user;
  }

  function signup(user, callback) {
    submit("signup", user, callback);
  }

  function login(user, callback) {
    submit("login", user, callback);
  }

  function submit(url, user, callback) {
    $http
      .post(`${consts.apiUrl}/${url}`, user)
      .then(function (resp) {
        localStorage.setItem(consts.userKey, JSON.stringify(resp.data));
        if (callback) callback(null, resp.data);
      })
      .catch(function (resp) {
        if (callback) callback(resp.data, null);
        if (
          resp.data.error ===
          "TypeError: Cannot destructure property 'password' of 'req.data' as it is null."
        ) {
          msgs.addError("preencha os campos");
        } else if (resp.data.error === "usuario já existe") {
          msgs.addError("Usuario ja existe");
        } else if (resp.data.error === "falha de formulario") {
          msgs.addError("Senha muito pequena");
        } else if (resp.data.error === "Error: senhas nao sao iguais") {
          msgs.addError("As senhas nao sao iguais");
        }
      });
  }

  function logout(callback) {
    user = null;
    localStorage.removeItem(consts.userKey);
    $http.defaults.headers.common.token = "";
    if (callback) callback(null);
  }

  function validateToken(token, callback) {
    const tokenBearer = `Bearer ${token}`;
    if (tokenBearer) {
      $http({
        method: "POST",
        url: `${consts.apiUrl}/verifyToken`,
        headers: {
          token: `Bearer ${token}`,
          "Content-Type": "Application/x-www-form-urlencoded",
        },
      })
        .then((resp) => {
          if (!resp.data.valid) {
            logout();
          } else {
            $http.defaults.headers.common.Authorization = getUser().tokenBearer;
          }
          if (callback) callback(null, resp.data.valid);
        })
        .catch(function (resp) {
          if (callback) {
            callback(resp);
            console.log(resp);
          }
        });
    }
  }

  function ValidadeUser() {
    try {
      const user = getUser();
      const authPage = "#!/login";
      const isAuthPage = $window.location.href.includes(authPage);
      if (!user && !isAuthPage) {
        $window.location.href = authPage;
      } else if (user && !user.isValid) {
        validateToken(user.userLogin, (err, valid) => {
          if (!valid) {
            $window.location.href = authPage;
            logout();
          } else {
            user.isValid = true;
            $http.defaults.headers.common.token = `Bearer ${user.userLogin}`;
            user.isValid ? ($window.location.href = "#!/dashboard") : authPage;
          }
        });
      }
    } catch (err) {
      console.log(err);
    }
  }

  return { signup, login, logout, getUser, validateToken, ValidadeUser };
}
