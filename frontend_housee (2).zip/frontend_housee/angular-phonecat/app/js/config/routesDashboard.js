const app = angular.module("BankApp").config([
  "$stateProvider",
  "$urlRouterProvider",
  function ($stateProvider) {
    $stateProvider.state("dashboard", {
      url: "/dashboard",
      templateUrl:
        "../../views/dashboard/contentDashboard/homeDashboard.template.html",
      controller: "DashboardCtrl",
    });
    $stateProvider.state("bank", {
      url: "/dashboard-bank",
      templateUrl:
        "../../views/dashboard/contentDashboard/bankDashboard.template.html",
    });
    $stateProvider.state("historic", {
      url: "/dashboard-historic",
      templateUrl:
        "../../views/dashboard/contentDashboard/historicDashboard.template.html",
    });
    $stateProvider.state("nubank", {
      url: "/dashboard-nubank",
      templateUrl:
        "../../views/dashboard/contentDashboard/nubankDashboard.template.html",
    });
    $stateProvider.state("adm", {
      url: "/dashboard-adm",
      templateUrl:
        "../../views/dashboard/contentDashboard/admDashboard.template.html",
    });
  },
]);
