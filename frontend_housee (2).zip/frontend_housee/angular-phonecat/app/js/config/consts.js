angular
  .module("BankApp")
  .constant("consts", {
    appName: "BankApp",
    version: "1.0",
    owner: "wiinan",
    year: "2021",
    apiUrl: "http://localhost:3000/api",
    userKey: "_bank_app_user",
  })
  .run([
    "$rootScope",
    "consts",
    function ($rootScope, consts) {
      $rootScope.consts = consts;
    },
  ]);
