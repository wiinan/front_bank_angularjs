angular
  .module("BankApp")
  .config(function ($routeProvider, $httpProvider) {
    $routeProvider.when("/", {
      templateUrl: "../../views/homePage/homePage.template.html",
    });

    $routeProvider.when("/login", {
      templateUrl: "../../views/loginScreen/loginScreen.template.html",
      controller: "AuthCtrl",
    });

    $routeProvider.when("/register", {
      templateUrl: "../../views/registerScreen/registerScreen.template.html",
      controller: "AuthCtrl",
    });

    $routeProvider.when("/dashboard", {
      templateUrl: "../../views/dashboard/dashboard.template.html",
    });

    $routeProvider.when("/dashboard-bank", {
      templateUrl: "../../views/dashboard/dashboard.template.html",
    });

    $routeProvider.when("/dashboard-historic", {
      templateUrl: "../../views/dashboard/dashboard.template.html",
    });

    $routeProvider.when("/dashboard-adm", {
      templateUrl: "../../views/dashboard/dashboard.template.html",
    });
    
    $routeProvider.when("/dashboard-nubank", {
      templateUrl: "../../views/dashboard/dashboard.template.html",
    });

    $routeProvider.when("/404", {
      templateUrl: "../../views/notFound/notFound.template.html",
    });

    $httpProvider.interceptors.push("handleResponseError");

    // $routeProvider.otherwise();
  })
  .run([
    "$rootScope",
    "auth",
    function ($rootScope, auth) {
      $rootScope.$on("$locationChangeStart", function () {
        auth.ValidadeUser();
      });

      auth.ValidadeUser();
    },
  ]);
