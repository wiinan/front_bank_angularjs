angular
  .module("BankApp")
  .controller("debitCtrl", ["$scope", "$http", "consts", debitController]);

function debitController($scope, $http, consts) {
  const url = `${consts.apiUrl}/debit`;

  $scope.TotalDebits = function () {
    $http({ method: "get", url: url }).then(async function (resp) {
      let debitValues = resp.data;
      let debitTotal = 0;
      await debitValues.forEach((data) => {
        debitTotal = debitTotal + data.value;
      });
      $scope.ShowDebits = parseFloat(debitTotal);
    }),
      function (err) {
        console.log(err);
      };
  };
  $scope.TotalDebits();

  $scope.refresh = function () {
    $http.get(url, $scope.debitUser).then(function (resp) {
      $scope.debitUser = resp.data;
    });
  };
  $scope.refresh();
}
