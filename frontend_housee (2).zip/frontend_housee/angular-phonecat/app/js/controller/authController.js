angular
  .module("BankApp")
  .controller("AuthCtrl", [
    "auth",
    "msgs",
    "$window",
    "$scope",
    AuthController,
  ]);
function AuthController(auth, msgs, $window, $scope) {
  $scope.formLogin = {
    email: null,
    name: null,
    password: null,
    confirmPassword: null,
  };

  $scope.getUser = () => auth.getUser();

  $scope.logout = () => {
    auth.logout(() => ($window.location.href = "#!/login"));
  };

  $scope.login = function () {
    auth.login(
      { email: $scope.formLogin.email, password: $scope.formLogin.password },
      (err) =>
        err
          ? msgs.addError("Usuario ou senha Incorretos")
          : $window.location.reload()
    );
  };

  $scope.signup = function () {
    auth.signup(
      {
        email: $scope.formLogin.email,
        name: $scope.formLogin.name,
        password: $scope.formLogin.password,
        confirmPassword: $scope.formLogin.confirmPassword,
      },
      (err) => (err ? console.log(err) : ($window.location.href = "#!/login"))
    );
  };
}
