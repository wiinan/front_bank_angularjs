angular
  .module("BankApp")
  .controller("DashboardCtrl", [
    "$scope",
    "$http",
    "consts",
    DashboardController,
  ]);

function DashboardController($scope, $http, consts) {
  $scope.getTotal = function () {
    const url = `${consts.apiUrl}/billing`;
    $http({ method: "get", url: url }).then(async function (resp) {
      try {
        let creditsCalc = 0;
        let creditsTotal = resp.data;
        await creditsTotal.forEach((data) => {
          creditsCalc = creditsCalc + data.credits;
        });
        $scope.totalValue = creditsCalc;
      } catch (err) {
        console.log(err);
      }
    }),
      function (err) {
        console.log(err);
      };
  };
  $scope.getTotal();
}
