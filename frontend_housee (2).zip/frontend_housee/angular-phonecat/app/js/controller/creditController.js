angular
  .module("BankApp")
  .controller("creditCtrl", ["$scope", "$http", "consts", creditController]);

function creditController($scope, $http, consts) {
  const url = `${consts.apiUrl}/credit`;

  $scope.getSumary = function () {
    $http({ method: "get", url: url }).then(async function (resp) {
      let creditValues = resp.data;
      let creditTotal = 0;
      await creditValues.forEach((data) => {
        creditTotal = creditTotal + data.value;
      });
      $scope.showCredits = parseFloat(creditTotal);
    }),
      function (err) {
        console.log(err);
      };
  };
  $scope.getSumary();

  $scope.refreshCredits = function () {
    $http.get(url, $scope.creditUser).then(function (resp) {
      $scope.creditUser = resp.data;
    });
  };
  $scope.refreshCredits();
}
