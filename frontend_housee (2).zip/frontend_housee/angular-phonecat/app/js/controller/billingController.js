angular
  .module("BankApp")
  .controller("billingCtrl", [
    "$http",
    "consts",
    "msgs",
    "$scope",
    "$timeout",
    billingController,
  ]);

function billingController($http, consts, msgs, $scope) {
  // $scope.nome = 'Renan';

  // $timeout(() => {
  //   $scope.nome = 'Enéas'
  //   console.log('mudou')
  // });

  // $scope.clicou = function() {
  //   console.log('clicou', $scope.nome)
  // $scope.nome = 'Zé lindo'
  // }
  const url = `${consts.apiUrl}/billing`;
  $scope.checked = false;
  $scope.showTab = true;

  $scope.checker = function () {
    $scope.checked = !$scope.checked;
    $scope.showTab = !$scope.showTab;
  };

  $scope.refresh = function () {
    $http.get(url, $scope.billingcycles).then(function (resp) {
      $scope.billingcycles = resp.data;
    });
  };

  $scope.Create = function () {
    try {
      $http
        .post(url, $scope.billingcycle)
        .then(async function (resp) {
          msgs.addSuccess("Criado com sucesso!");
          $scope.refresh();
        })
        .catch(function (err) {
          if (
            err.data.error ===
            "SequelizeValidationError: notNull Violation: billingcycles.name cannot be null"
          ) {
            msgs.addError("O campo Nome é obrigatorio");
          } else if (err.data.error === "falha de formulario") {
            msgs.addError("O campo vazio é obrigatorio");
          }
          msgs.addError(err.data.error.message);
        });
    } catch (err) {
      console.log(err);
    }
  };

  $scope.showTabUpdate = function (billingcycle) {
    $scope.billingcycles = billingcycle;
  };

  $scope.showTabDelete = function (billingcycle) {
    $scope.billingcycles = billingcycle;
  };

  $scope.delete = function (billingcycle) {
    const deleteUrl = `${url}/${billingcycle.id}`;

    $http
      .delete(deleteUrl, billingcycle)
      .then(function (resp) {
        $scope.refresh();
        msgs.addSuccess("Conta de pagamento deletado");
      })
      .catch(function (err) {
        msgs.addError("Erro ao deletar pagamento");
      });
  };

  $scope.cloneValue = function (index, { name, value }) {
    $scope.billingcycle.credits.splice(index + 1, 0, { name, value });
  };

  $scope.refresh();
}
