angular.module("BankApp").component("loginComponent", {
  templateUrl: "../../../views/loginScreen/loginScreen.template.html",
});
