angular.module("BankApp").component("registerComponent", {
  templateUrl: "../../../views/registerScreen/registerScreen.template.html",
});
