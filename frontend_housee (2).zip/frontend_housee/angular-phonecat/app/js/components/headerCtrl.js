angular.module("BankApp").component("headerComponent", {
  templateUrl: "../../views/header.template.html",
});
