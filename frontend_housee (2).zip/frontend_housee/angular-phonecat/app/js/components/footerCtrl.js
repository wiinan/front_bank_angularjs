angular.module("BankApp").component("footerComponent", {
  templateUrl: "../../views/footer.template.html",
});
