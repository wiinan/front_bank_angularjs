angular.module("BankApp").component("headerBoardComponent", {
  templateUrl:
    "../../../views/dashboard/dashboardTemplate/headerBoard.template.html",
});
