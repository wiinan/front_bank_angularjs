angular.module("BankApp").component("sidebarBoardComponent", {
  templateUrl:
    "../../../views/dashboard/dashboardTemplate/sidebarBoard.template.html",
});
