angular.module("BankApp").component("boardComponent", {
  templateUrl: "../../../views/dashboard/dashboard.template.html",
});
