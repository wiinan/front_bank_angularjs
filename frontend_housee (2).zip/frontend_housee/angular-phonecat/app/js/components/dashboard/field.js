angular.module("BankApp").component("fieldComp", {
  bindings: {
    id: "@",
    label: "@",
    placeholder: "@",
    type: "@",
    model: "=",
  },
  template: `
    <div>
        <div class="form-group">
            <label for="{{$ctrl.id}}">{{$ctrl.label}}</label>
            <input id="{{$ctrl.id}}" class="form__control"
              placeholder="{{$ctrl.placeholder}}" type="{{$ctrl.type}}" 
              ng-model="$ctrl.model" />
        </div>
    </div>
  `,
});
