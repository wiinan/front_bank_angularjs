angular.module("BankApp").component("middleComponent", {
  templateUrl: "../../views/middleInitialPage.template.html",
});
