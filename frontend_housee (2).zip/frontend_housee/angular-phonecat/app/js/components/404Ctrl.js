angular.module("BankApp").component("404Component", {
  templateUrl: "../../views/notFound/notFound.template.html",
});
