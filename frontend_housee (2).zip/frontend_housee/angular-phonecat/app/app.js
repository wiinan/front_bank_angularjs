"use strict";

angular.module("BankApp", ["ngRoute", "toastr", "ui.router"]);
