import { StateService } from "@uirouter/core";
export declare function $IsStateFilter($state: StateService): any;
export declare function $IncludedByStateFilter($state: StateService): any;
