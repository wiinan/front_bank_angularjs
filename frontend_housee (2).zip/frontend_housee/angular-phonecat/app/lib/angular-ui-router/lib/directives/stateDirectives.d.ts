/** @hidden Used for typedoc */
export interface ng1_directive {
}
